#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "std_msgs/msg/string.hpp"
#include "std_msgs/msg/bool.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp" 

#include <cstdlib>
#include <algorithm>
#include <set>
#include <vector>
#include <chrono>
#include <memory>

class RobotVoiceNode : public rclcpp::Node
{
public:
    RobotVoiceNode()
    : Node("robot_voice_node"), awaiting_command_(false)
    {
        // Subscribe to STT result topic
        subscription_ = this->create_subscription<std_msgs::msg::String>(
            "/stt/result", 10,
            std::bind(&RobotVoiceNode::command_callback, this, std::placeholders::_1));
        
        client_ptr_ = rclcpp_action::create_client<nav2_msgs::action::NavigateToPose>(
            this, "navigate_to_pose");

        // Publisher to suppress Vosk STT while robot is speaking
        suppress_pub_ = this->create_publisher<std_msgs::msg::Bool>("/stt/supress", 10);
        RCLCPP_INFO(this->get_logger(), "Robot voice node is ready!");

        coqui_pub_ = this->create_publisher<std_msgs::msg::String>("speak", 10);
    }

private:
    struct Position {
        float x;
        float y;
    };

    std::vector<Position> positions = {
        {2.2, 1.16}, //a
        {2.78, 0.269}, //b
        {0.52, -1.13}, //c
        {0.1, 0.0} //d
    };
    

    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;
    rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr suppress_pub_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr coqui_pub_;
    rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::SharedPtr client_ptr_;
    rclcpp_action::ClientGoalHandle<nav2_msgs::action::NavigateToPose>::SharedPtr current_goal_handle_;
    rclcpp::TimerBase::SharedPtr timer_;

    bool awaiting_command_;
    std::vector<std::string> pending_goals_;
    size_t current_goal_index_ = 0;
    bool goal_active_ = false;
    
    void send_goal(){
        if (goal_active_ || current_goal_index_ >= pending_goals_.size()){
            return;
        }

        if (!client_ptr_->wait_for_action_server(std::chrono::seconds(5))){
            RCLCPP_ERROR(this->get_logger(), "Action server not available.");
            return;
        }
        std::string point = pending_goals_[current_goal_index_];
        Position pos;

        if (point == "painting a") pos = positions[0];
        else if (point == "painting b") pos = positions[1];
        else if (point == "painting c") pos = positions[2];
        else if(point == "painting d") pos = positions[3];

        auto goal_msg = nav2_msgs::action::NavigateToPose::Goal();

        goal_msg.pose.header.frame_id = "map";
        goal_msg.pose.header.stamp = this->now();

        goal_msg.pose.pose.position.x = pos.x;
        goal_msg.pose.pose.position.y = pos.y;
        goal_msg.pose.pose.orientation.w = 1.0;
        

        auto options = rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::SendGoalOptions();
        options.result_callback = std::bind(&RobotVoiceNode::nav2_result_callback, this, std::placeholders::_1);
        
        RCLCPP_INFO(this->get_logger(), "Sending goal to (%.2f , %.2f)", pos.x, pos.y);
        auto future_goal_handle = client_ptr_->async_send_goal(goal_msg, options);

        std::thread([this, future_goal_handle]() mutable{
            auto result = future_goal_handle.get();
            current_goal_handle_ = result;
        }).detach();

        goal_active_ = true;
    }

    void nav2_result_callback(const rclcpp_action::ClientGoalHandle<nav2_msgs::action::NavigateToPose>::WrappedResult & result){
        goal_active_ = false;

        if (result.code == rclcpp_action::ResultCode::SUCCEEDED){
            RCLCPP_INFO(this->get_logger(), "Goal %zu succeeded", current_goal_index_);
            current_goal_index_++;
            send_goal();
        }
        else{
            RCLCPP_WARN(this->get_logger(), "Goal %zu failed (code %d). Stopping.", current_goal_index_, result.code);
            pending_goals_.clear(); // remove all current goals from previous command
        }
    }
    void speak(const std::string &text)
    {
        RCLCPP_INFO(this->get_logger(), "Speaking: '%s'", text.c_str());

        // Suppress Vosk STT
        std_msgs::msg::Bool suppress_msg;
        suppress_msg.data = true;
        suppress_pub_->publish(suppress_msg);

        // Publish msg for TTS
        std_msgs::msg::String msg;
        msg.data = text;
        coqui_pub_->publish(msg);

        // Wait to ensure speech is complete
        rclcpp::sleep_for(std::chrono::seconds(3));

        // Resume Vosk STT
        suppress_msg.data = false;
        suppress_pub_->publish(suppress_msg);
    }

    void command_callback(const std_msgs::msg::String::SharedPtr msg)
    {
        std::string command = msg->data;

        // Convert to lowercase for matching
        std::transform(command.begin(), command.end(), command.begin(), ::tolower);

        std::string response = "I don't understand.";

        if (!awaiting_command_) {
            // Waiting for wake word
            if (command.find("hey terry") !=std::string::npos) { //find() returns the index of the first character it is looking for
                response = "Listening.";
                awaiting_command_ = true;
                speak(response);
            } else {
                RCLCPP_INFO(this->get_logger(), "Ignoring (waiting for 'hey terry'): '%s'", command.c_str());
            }
            return;
        }

        if (command.find("cancel that") !=std::string::npos){
            speak("Cancelling previous command.");
            client_ptr_->async_cancel_goal(current_goal_handle_);
            goal_active_ = false;
            pending_goals_.clear();
            awaiting_command_ = false;
            return;
        }
        
        const std::set<std::string> valid_points = {"painting a","painting b","painting c","painting d"};
        std::vector<std::string> points;

        for (const auto& pt: valid_points){
            
            if(command.find(pt) !=std::string::npos){
                points.push_back(pt);
            }
        }

        if (points.empty()) {
            speak("Sorry, unrecogniseable command.");
            awaiting_command_ = false;
            return;
            // still awaiting_command_ = true
        }

        if(!points.empty()){
            std::string reply = "Okay, going to ";
            if(points.size() == 1){
                reply += points[0];
            }
            else{
                for (size_t i = 0; i < points.size(); i++){
                    reply += points[i];
                    if (i == points.size() -2){
                        reply += " and ";
                    }
                    else if (i < points.size() - 2)
                        reply += ", ";
                }
            }
                
            reply = reply + ".";
            response = reply;
            speak(response);
    
            pending_goals_ = points;
            current_goal_index_ = 0;
            send_goal();
            awaiting_command_ = false;            
        }
    }
};



int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<RobotVoiceNode>());
    rclcpp::shutdown();
    return 0;
}